
<!DOCTYPE html>
<html lang="en">

  <head>

    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="">
    <meta name="author" content="">

    <title>University of Delhi</title>

    <!-- Bootstrap core CSS -->
    <link href="vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">

    <!-- Custom fonts for this template -->
    <link href="vendor/font-awesome/css/font-awesome.min.css" rel="stylesheet" type="text/css">
    <link href="https://fonts.googleapis.com/css?family=Montserrat:400,700" rel="stylesheet" type="text/css">
    <link href='https://fonts.googleapis.com/css?family=Kaushan+Script' rel='stylesheet' type='text/css'>
    <link href='https://fonts.googleapis.com/css?family=Droid+Serif:400,700,400italic,700italic' rel='stylesheet' type='text/css'>
    <link href='https://fonts.googleapis.com/css?family=Roboto+Slab:400,100,300,700' rel='stylesheet' type='text/css'>

    <!-- Custom styles for this template -->
    <link href="css/agency.min.css" rel="stylesheet">
	<link href="css/drop.css" rel="stylesheet">
	<link href="css/agency.css" rel="stylesheet">
    <style>
	img{
	box-shadow:2px 2px 10px black;
	border-radius:50%;
	
	}
	img:hover{
	padding:10px;
	
	
	}
        
   h1{color:yellow;)

	
	</style>
  </head>

  <body id="page-top">

    <!-- Navigation -->
    <nav class="navbar navbar-expand-lg navbar-dark black fixed-top" id="mainNav">
      <div class="container">
        <a class="navbar-brand js-scroll-trigger" href="#page-top">University of Delhi</a>
        <button class="navbar-toggler navbar-toggler-right" type="button" data-toggle="collapse" data-target="#navbarResponsive" aria-controls="navbarResponsive" aria-expanded="false" aria-label="Toggle navigation">
          Menu
          <i class="fa fa-bars"></i>
        </button>
        <div class="collapse navbar-collapse" id="navbarResponsive">
          <ul class="navbar-nav text-uppercase ml-auto">
            <li class="nav-item">
              <a class="nav-link js-scroll-trigger" href="#about">About</a>
            </li>
                        <li class="nav-item">
              <a class="nav-link js-scroll-trigger" href="#colleges">Colleges</a>
            </li> 
			<li class="nav-item">
              <a class="nav-link js-scroll-trigger" href="#skill">Skill Courses</a>
            </li>	
		
		    <li class="nav-item">
              <a class="nav-link js-scroll-trigger" href="#team">Team</a>
            </li>
            <li class="nav-item">
              <a class="nav-link js-scroll-trigger" href="#contact">Contact</a>
			  

            </li>
			<li class="nav-item">
              <a class="nav-link js-scroll-trigger" href="rank_pred/contact.php" target="_blank">Skill Course Predictor</a>
			  

            </li>
         

			
            
          </ul>
        </div>
      </div>
    </nav>

    <!-- Header -->
    <header class="masthead">
      <div class="container">
        <div class="intro-text">
          <div class="intro-lead-in"><h1>University of Delhi</h1></div>
          <a class="btn btn-primary btn-xl text-uppercase js-scroll-trigger" href="#colleges">Scroll Down For More</a>
        </div>
      </div>
    </header>
  <a name="scroll_down"><section id="colleges"></a>
      <div class="container">
        <div class="row">
          <div class="col-lg-12 text-center">
            <h2 class="section-heading text-uppercase">Top Colleges</h2>
            <h3 class="section-subheading text-muted">(“A university is just a group of buildings gathered around a library” )</h3>
          </div>
        </div>
        <div class="row text-center">
          <div class="col-md-3">
            <img src= "./img/hans1.jpg" alt= "Hansraj College" height="200px" width="230px">
            <h4 class="service-heading"><a href="services/hansraj.html" target="_blank">Hansraj College</a></h4>
            <p class="text-muted">Hansraj College is a constituent college of the University of Delhi, in New Delhi, India.</p>
          </div>
          <div class="col-md-3">
			<img src= "./img/hindu.jpg" alt= "Women Helpline Scheme" height="200px" width="230px">
            <h4 class="service-heading"><a href="services/hindu.html" target="_blank" >Hindu College</a></h4>
            <p class="text-muted">Hindu College is one of the colleges under the affiliation of University of Delhi in Delhi, India. </p>
          </div>
          <div class="col-md-3">
          <img src= "./img/dc.jpg" alt= "Mahila Police Volunteers" height="200px" width="230px">
            <h4 class="service-heading"><a href="services/daulat.html" target="_blank">Daulat Ram College</a></h4>
            <p class="text-muted">Daulat Ram College (DRC) is a women's college under University of Delhi that was founded in 1960. </p>
		  </div>
		  <div class="col-md-3">
            <img src= "./img/ssc.jpg" alt= "Rajiv Gandhi National Crèche Scheme" height="200px" width="230px">
            <h4 class="service-heading"><a href="services/st.html" target="_blank">St. Stephen's College</a></h4>
            <p class="text-muted">St. Stephen's College is a constituent college of the University of Delhi located in Delhi, India.</p>
        </div>
		 <div class="col-md-3">
            <img src= "./img/miran.jpg" alt= "Rajiv Gandhi National Crèche Scheme" height="200px" width="230px">
            <h4 class="service-heading"><a href="services/miranda.html" target="_blank">Miranda College</a></h4>
            <p class="text-muted">Miranda House is constituent college for women at the University of Delhi in India.</p>
        </div>
		<div class="col-md-3">
            <img src= "./img/ddl.jpg" alt= "Rajiv Gandhi National Crèche Scheme" height="200px" width="230px">
            <h4 class="service-heading"><a href="services/ddl.html" target="_blank">Deen Dyal Upadhya College</a></h4>
            <p class="text-muted">Deen Dayal Upadhyaya College is one of the constituent colleges of the University of Delhi in India.</p>
        </div>
		<div class="col-md-3">
            <img src= "./img/gargi.jpg" alt= "Rajiv Gandhi National Crèche Scheme" height="200px" width="230px">
            <h4 class="service-heading"><a href="services/gargi.html" target="_blank">Gargi College</a></h4>
            <p class="text-muted">Gargi College is one of the top colleges affiliated to the University of Delhi.</p>
        </div>
		<div class="col-md-3">
            <img src= "./img/srv.jpg" alt= "Rajiv Gandhi National Crèche Scheme" height="200px" width="230px">
            <h4 class="service-heading"><a href="services/sri.html" target="_blank">Sri Venkateswara College</a></h4>
            <p class="text-muted">Sri Venkateswara College is a co-ed constituent college of the University of Delhi in New Delhi, India.</p>
        </div>
      </div>
	  
	 </div>
	 <center><a class="btn btn-primary btn-xl text-uppercase js-scroll-trigger" href="college.html" target="_blank">More</a></center>
    </section>
	
	<!-- Hospital Info -->
    <section id="skill">
      <div class="container">
        <div class="row">
          <div class="col-lg-12 text-center">
            <h2 class="section-heading text-uppercase">Skill Courses</h2>
            <h3 class="section-subheading text-muted">(The course gives you an opportunity to engage in various rural and community development activities.)</h3>
          </div>
		  <div class="col-lg-12 text-center">
            <h2 class="service-heading"><a href="http://du.ac.in/du/uploads/03092016_BVoc.pdf" >Bachelor of Vocations</a></h2>
            <h3 class="section-subheading text-muted">(It has been introduced in Delhi University)</h3>
          </div>
		  
        </div>
		
        <div class="row text-center">
          <div class="col-md-3">
            <a href="http://www.du.ac.in/du/uploads/colleges/Kalindi/24082015_Kalindi.pdf"><img src= "./img/wd1.jpg" alt= "AIIMS" height="200px" width="250px"></a>
            <h4 class="service-heading"><a href="skill_courses/wd.html">Web Designing</a></h4>
            <p class="text-muted">Web design encompasses many different skills and disciplines in the production and maintenance of websites. The different areas of web design include web graphic design; interface design; authoring, including standardised code and proprietary software.</p>
          </div>
          <div class="col-md-3">
			<a href="http://www.du.ac.in/du/uploads/colleges/Kalindi/24082015_Kalindi.pdf"><img src= "./img/pt.jpg" alt= "Tata Memorial Hospital" height="200px" width="250px"></a>
            <h4 class="service-heading"><a href="skill_courses/pt.html">Printing Technology</a></h4>
            <p class="text-muted">Printing is a process for reproducing text and images using a master form or template. The earliest non-paper products involving printing include cylinder seals and objects such as the Cyrus Cylinder and the Cylinders of Nabonidus.</p>
          </div>
          <div class="col-md-3">
          <a href="http://rcdu.in/"><img src= "./img/sd.jpg" alt= "King Edward Memorial Hospital" height="200px" width="250px" ></a>
            <h4 class="service-heading"><a href="skill_courses/sd2.html">Software Development</a></h4>
            <p class="text-muted">Software development is the process of conceiving, specifying, designing, programming, documenting, testing, and bug fixing involved in creating and maintaining applications, frameworks, or other software components.</p>
		  </div>
		  <div class="col-md-3">
            <a href="http://rcdu.in/"><img src= "./img/bo.jpg" alt= "Ram Manohar Lohia Hospital" height="200px" width="250px"></a>
            <h4 class="service-heading"><a href="skill_courses/bo.html">Banking Operations</a></h4>
            <p class="text-muted"> Banking operations make sure our processes and transactions are executed correctly, which minimising risk and maximising quality of service. The legal transactions executed by a bank in its daily business, such as providing loans, mortgages and investments.</p>
        </div>
		 <div class="col-md-4">
            <a href="http://www.jmc.ac.in/docs/b.voc-course-jmc-16--new.pdf"><img src= "./img/hm.jpg" alt= "Ram Manohar Lohia Hospital" height="200px" width="250px"></a>
            <h4 class="service-heading"><a href="skill_courses/hm.html">Healthcare Management</a></h4>
            <p class="text-muted"> The management of any health system is typically directed through a set of policies and plans adopted by government, private sector business and other groups in areas such as personal healthcare delivery and financing, pharmaceuticals, health human resources, and public health.</p>
        </div>
		 <div class="col-md-4">
            <a href="http://www.jmc.ac.in/docs/b.voc-course-jmc-16--new.pdf"><img src= "./img/rt.png" alt= "Ram Manohar Lohia Hospital" height="200px" width="250px"></a>
            <h4 class="service-heading"><a href="skill_courses/rm.html">Retail Management & IT</a></h4>
            <p class="text-muted">A process of promoting greater sales and customer satisfaction by gaining a better understanding of the consumers of goods and services produced by a company.Retail Management referes to all the processes which help the customers to procure the desired merchandise from the retail stores for their end use.</p>
        </div>
		<div class="col-md-4">
            <a href="http://mac.du.ac.in/"><img src= "./img/tv.jpg" alt= "Ram Manohar Lohia Hospital" height="200px" width="250px"></a>
            <h4 class="service-heading"><a href="skill_courses/tv.html">TV Programme & News Production</a></h4>
            <p class="text-muted">The production company is often separate from the broadcaster. The executive producer, often the show's creator, is in charge of running the show.The production control room is the place in a television studio in which the composition of the outgoing program takes place.</p>
        </div>
      </div>
	 
    </section>

    <!-- About -->
    <section id="about">
      <div class="container">
        <div class="row">
          <div class="col-lg-12 text-center">
            <h2 class="section-heading text-uppercase">About</h2>
            <h3 class="section-subheading text-muted">(Techno-ster)</h3>
          </div>
        </div>
        <div class="row">
          <div class="col-lg-12">
            <ul class="timeline">
              <li>
                <div class="timeline-image">
                  <img class="rounded-circle img-fluid" src="img/about/1.jpg" alt="">
                </div>
                <div class="timeline-panel">
                  <div class="timeline-heading">
                    <h4>2018-2019</h4>
                    <h4 class="subheading">Our Humble Beginnings</h4>
                  </div>
                  <div class="timeline-body">
                    <p class="text-muted">The Smart India Hackathon '18 was a boost start when we saw our college participating in it. That was the time when we decided to be a part of such an Extravaganza.</p>
                  </div>
                </div>
              </li>
              <li class="timeline-inverted">
                <div class="timeline-image">
                  <h4>Be a Part
                    <br>Of Our
                    <br>Story!</h4>
                </div>
              </li>
            </ul>
          </div>
        </div>
      </div>
    </section>

    <!-- Team -->
    <section class="bg-light" id="team">
      <div class="container">
        <div class="row">
          <div class="col-lg-12 text-center">
            <h2 class="section-heading text-uppercase">Our Amazing Team</h2>
            <h3 class="section-subheading text-muted">Unity Is The Pathway Of Success</h3>
          </div>
        </div>
        <div class="row">
          <div class="col-sm-6">
            <div class="team-member">
              <img class="mx-auto rounded-circle" src="img/team/nupur.jpg" alt="">
              <h4>Nupur Jha</h4>
              <p class="text-muted">Web Developer</p>
              <ul class="list-inline social-buttons">
                <li class="list-inline-item">
                  <a href="#">
                    <i class="fa fa-twitter"></i>
                  </a>
                </li>
                <li class="list-inline-item">
                  <a href="https://www.facebook.com/profile.php?id=100008336583730" target="_blank">
                    <i class="fa fa-facebook"></i>
                  </a>
                </li>
                <li class="list-inline-item">
                  <a href="#">
                    <i class="fa fa-linkedin"></i>
                  </a>
                </li>
              </ul>
            </div>
          </div>
          <div class="col-sm-6">
            <div class="team-member">
              <img class="mx-auto rounded-circle" src="img/team/avantika.jpg" alt="">
              <h4>Avantika Aggarwal</h4>
              <p class="text-muted">Web Developer</p>
              <ul class="list-inline social-buttons">
                <li class="list-inline-item">
                  <a href="#" target="_blank">
                    <i class="fa fa-twitter"></i>
                  </a>
                </li>
                <li class="list-inline-item">
                  <a href="https://www.facebook.com/profile.php?id=100000071937538" target="_blank">
                    <i class="fa fa-facebook"></i>
                  </a>
                </li>
                <li class="list-inline-item">
                  <a href="#" target="_blank">
                    <i class="fa fa-linkedin"></i>
                  </a>
                </li>
              </ul>
            </div>
          </div>
          
        </div><br>
        <div class="row">
          <div class="col-lg-12 mx-auto text-center">
            <p class="large text-muted">Techno-ster team worked together to Bring up a Portal that maps all the information regarding SKILL COURSES and colleges of DELHI UNIVERSITY.</p>
          </div>
        </div>
      </div>
    </section>
  <!-- Contact -->
    <section id="contact">
      <div class="container">
        <div class="row">
          <div class="col-lg-12 text-center">
            <h2 class="section-heading text-uppercase">Contact Us</h2>
            <h3 class="section-subheading text-muted">Lorem ipsum dolor sit amet consectetur.</h3>
          </div>
        </div>
        <div class="row">
          <div class="col-lg-12">
            <form id="contactForm" name="sentMessage" novalidate>
              <div class="row">
                <div class="col-md-6">
                  <div class="form-group">
                    <input class="form-control" id="name" type="text" placeholder="Your Name *" required data-validation-required-message="Please enter your name.">
                    <p class="help-block text-danger"></p>
                  </div>
                  <div class="form-group">
                    <input class="form-control" id="email" type="email" placeholder="Your Email *" required data-validation-required-message="Please enter your email address.">
                    <p class="help-block text-danger"></p>
                  </div>
                  <div class="form-group">
                    <input class="form-control" id="phone" type="tel" placeholder="Your Phone *" required data-validation-required-message="Please enter your phone number.">
                    <p class="help-block text-danger"></p>
                  </div>
                </div>
                <div class="col-md-6">
                  <div class="form-group">
                    <textarea class="form-control" id="message" placeholder="Your Message *" required data-validation-required-message="Please enter a message."></textarea>
                    <p class="help-block text-danger"></p>
                  </div>
                </div>
                <div class="clearfix"></div>
                <div class="col-lg-12 text-center">
                  <div id="success"></div>
                  <button id="sendMessageButton" class="btn btn-primary btn-xl text-uppercase" type="submit">Send Message</button>
                </div>
              </div>
            </form>
          </div>
        </div>
      </div>
    </section>

    <!-- Footer -->
    <footer>
      <div class="container">
        <div class="row">
          <div class="col-md-4">
            <span class="copyright">Copyright &copy; Your Website 2018</span>
          </div>
          <div class="col-md-4">
            <ul class="list-inline social-buttons">
              <li class="list-inline-item">
                <a href="#">
                  <i class="fa fa-twitter"></i>
                </a>
              </li>
              <li class="list-inline-item">
                <a href="#">
                  <i class="fa fa-facebook"></i>
                </a>
              </li>
              <li class="list-inline-item">
                <a href="#">
                  <i class="fa fa-linkedin"></i>
                </a>
              </li>
            </ul>
          </div>
          <div class="col-md-4">
            <ul class="list-inline quicklinks">
              <li class="list-inline-item">
                <a href="#">Privacy Policy</a>
              </li>
              <li class="list-inline-item">
                <a href="#">Terms of Use</a>
              </li>
            </ul>
          </div>
        </div>
      </div>
    </footer>

    <!-- Portfolio Modals -->

    <!-- Modal 1 -->
    <div class="portfolio-modal modal fade" id="portfolioModal1" tabindex="-1" role="dialog" aria-hidden="true">
      <div class="modal-dialog">
        <div class="modal-content">
          <div class="close-modal" data-dismiss="modal">
            <div class="lr">
              <div class="rl"></div>
            </div>
          </div>
          <div class="container">
            <div class="row">
              <div class="col-lg-8 mx-auto">
                <div class="modal-body">
                  <!-- Project Details Go Here -->
                  <h2 class="text-uppercase">Project Name</h2>
                  <p class="item-intro text-muted">Lorem ipsum dolor sit amet consectetur.</p>
                  <img class="img-fluid d-block mx-auto" src="img/portfolio/01-full.jpg" alt="">
                  <p>Use this area to describe your project. Lorem ipsum dolor sit amet, consectetur adipisicing elit. Est blanditiis dolorem culpa incidunt minus dignissimos deserunt repellat aperiam quasi sunt officia expedita beatae cupiditate, maiores repudiandae, nostrum, reiciendis facere nemo!</p>
                  <ul class="list-inline">
                    <li>Date: January 2017</li>
                    <li>Client: Threads</li>
                    <li>Category: Illustration</li>
                  </ul>
                  <button class="btn btn-primary" data-dismiss="modal" type="button">
                    <i class="fa fa-times"></i>
                    Close Project</button>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>

    <!-- Modal 2 -->
    <div class="portfolio-modal modal fade" id="portfolioModal2" tabindex="-1" role="dialog" aria-hidden="true">
      <div class="modal-dialog">
        <div class="modal-content">
          <div class="close-modal" data-dismiss="modal">
            <div class="lr">
              <div class="rl"></div>
            </div>
          </div>
          <div class="container">
            <div class="row">
              <div class="col-lg-8 mx-auto">
                <div class="modal-body">
                  <!-- Project Details Go Here -->
                  <h2 class="text-uppercase">Project Name</h2>
                  <p class="item-intro text-muted">Lorem ipsum dolor sit amet consectetur.</p>
                  <img class="img-fluid d-block mx-auto" src="img/portfolio/02-full.jpg" alt="">
                  <p>Use this area to describe your project. Lorem ipsum dolor sit amet, consectetur adipisicing elit. Est blanditiis dolorem culpa incidunt minus dignissimos deserunt repellat aperiam quasi sunt officia expedita beatae cupiditate, maiores repudiandae, nostrum, reiciendis facere nemo!</p>
                  <ul class="list-inline">
                    <li>Date: January 2017</li>
                    <li>Client: Explore</li>
                    <li>Category: Graphic Design</li>
                  </ul>
                  <button class="btn btn-primary" data-dismiss="modal" type="button">
                    <i class="fa fa-times"></i>
                    Close Project</button>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>

    <!-- Modal 3 -->
    <div class="portfolio-modal modal fade" id="portfolioModal3" tabindex="-1" role="dialog" aria-hidden="true">
      <div class="modal-dialog">
        <div class="modal-content">
          <div class="close-modal" data-dismiss="modal">
            <div class="lr">
              <div class="rl"></div>
            </div>
          </div>
          <div class="container">
            <div class="row">
              <div class="col-lg-8 mx-auto">
                <div class="modal-body">
                  <!-- Project Details Go Here -->
                  <h2 class="text-uppercase">Project Name</h2>
                  <p class="item-intro text-muted">Lorem ipsum dolor sit amet consectetur.</p>
                  <img class="img-fluid d-block mx-auto" src="img/portfolio/03-full.jpg" alt="">
                  <p>Use this area to describe your project. Lorem ipsum dolor sit amet, consectetur adipisicing elit. Est blanditiis dolorem culpa incidunt minus dignissimos deserunt repellat aperiam quasi sunt officia expedita beatae cupiditate, maiores repudiandae, nostrum, reiciendis facere nemo!</p>
                  <ul class="list-inline">
                    <li>Date: January 2017</li>
                    <li>Client: Finish</li>
                    <li>Category: Identity</li>
                  </ul>
                  <button class="btn btn-primary" data-dismiss="modal" type="button">
                    <i class="fa fa-times"></i>
                    Close Project</button>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>

    <!-- Modal 4 -->
    <div class="portfolio-modal modal fade" id="portfolioModal4" tabindex="-1" role="dialog" aria-hidden="true">
      <div class="modal-dialog">
        <div class="modal-content">
          <div class="close-modal" data-dismiss="modal">
            <div class="lr">
              <div class="rl"></div>
            </div>
          </div>
          <div class="container">
            <div class="row">
              <div class="col-lg-8 mx-auto">
                <div class="modal-body">
                  <!-- Project Details Go Here -->
                  <h2 class="text-uppercase">Project Name</h2>
                  <p class="item-intro text-muted">Lorem ipsum dolor sit amet consectetur.</p>
                  <img class="img-fluid d-block mx-auto" src="img/portfolio/04-full.jpg" alt="">
                  <p>Use this area to describe your project. Lorem ipsum dolor sit amet, consectetur adipisicing elit. Est blanditiis dolorem culpa incidunt minus dignissimos deserunt repellat aperiam quasi sunt officia expedita beatae cupiditate, maiores repudiandae, nostrum, reiciendis facere nemo!</p>
                  <ul class="list-inline">
                    <li>Date: January 2017</li>
                    <li>Client: Lines</li>
                    <li>Category: Branding</li>
                  </ul>
                  <button class="btn btn-primary" data-dismiss="modal" type="button">
                    <i class="fa fa-times"></i>
                    Close Project</button>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>

    <!-- Modal 5 -->
    <div class="portfolio-modal modal fade" id="portfolioModal5" tabindex="-1" role="dialog" aria-hidden="true">
      <div class="modal-dialog">
        <div class="modal-content">
          <div class="close-modal" data-dismiss="modal">
            <div class="lr">
              <div class="rl"></div>
            </div>
          </div>
          <div class="container">
            <div class="row">
              <div class="col-lg-8 mx-auto">
                <div class="modal-body">
                  <!-- Project Details Go Here -->
                  <h2 class="text-uppercase">Project Name</h2>
                  <p class="item-intro text-muted">Lorem ipsum dolor sit amet consectetur.</p>
                  <img class="img-fluid d-block mx-auto" src="img/portfolio/05-full.jpg" alt="">
                  <p>Use this area to describe your project. Lorem ipsum dolor sit amet, consectetur adipisicing elit. Est blanditiis dolorem culpa incidunt minus dignissimos deserunt repellat aperiam quasi sunt officia expedita beatae cupiditate, maiores repudiandae, nostrum, reiciendis facere nemo!</p>
                  <ul class="list-inline">
                    <li>Date: January 2017</li>
                    <li>Client: Southwest</li>
                    <li>Category: Website Design</li>
                  </ul>
                  <button class="btn btn-primary" data-dismiss="modal" type="button">
                    <i class="fa fa-times"></i>
                    Close Project</button>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>

    <!-- Modal 6 -->
    <div class="portfolio-modal modal fade" id="portfolioModal6" tabindex="-1" role="dialog" aria-hidden="true">
      <div class="modal-dialog">
        <div class="modal-content">
          <div class="close-modal" data-dismiss="modal">
            <div class="lr">
              <div class="rl"></div>
            </div>
          </div>
          <div class="container">
            <div class="row">
              <div class="col-lg-8 mx-auto">
                <div class="modal-body">
                  <!-- Project Details Go Here -->
                  <h2 class="text-uppercase">Project Name</h2>
                  <p class="item-intro text-muted">Lorem ipsum dolor sit amet consectetur.</p>
                  <img class="img-fluid d-block mx-auto" src="img/portfolio/06-full.jpg" alt="">
                  <p>Use this area to describe your project. Lorem ipsum dolor sit amet, consectetur adipisicing elit. Est blanditiis dolorem culpa incidunt minus dignissimos deserunt repellat aperiam quasi sunt officia expedita beatae cupiditate, maiores repudiandae, nostrum, reiciendis facere nemo!</p>
                  <ul class="list-inline">
                    <li>Date: January 2017</li>
                    <li>Client: Window</li>
                    <li>Category: Photography</li>
                  </ul>
                  <button class="btn btn-primary" data-dismiss="modal" type="button">
                    <i class="fa fa-times"></i>
                    Close Project</button>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>

    <!-- Bootstrap core JavaScript -->
    <script src="vendor/jquery/jquery.min.js"></script>
    <script src="vendor/bootstrap/js/bootstrap.bundle.min.js"></script>

    <!-- Plugin JavaScript -->
    <script src="vendor/jquery-easing/jquery.easing.min.js"></script>

    <!-- Contact form JavaScript -->
    <script src="js/jqBootstrapValidation.js"></script>
    <script src="js/contact_me.js"></script>

    <!-- Custom scripts for this template -->
    <script src="js/agency.min.js"></script>

  </body>

</html>
