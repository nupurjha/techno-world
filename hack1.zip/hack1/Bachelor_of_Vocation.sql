-- phpMyAdmin SQL Dump
-- version 4.7.4
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: May 26, 2018 at 02:26 PM
-- Server version: 10.1.26-MariaDB
-- PHP Version: 7.1.8

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `bvoc`
--

-- --------------------------------------------------------

--
-- Table structure for table `Bachelor_of_Vocation`
--

CREATE TABLE `bachelor_of_vocation` (
  `percentage` decimal(20,0) NOT NULL,
  `courses` varchar(1000) DEFAULT NULL,
  `colleges` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `Bachelor_of_Vocation`
--

INSERT INTO `Bachelor_of_Vocation` (`percentage`, `courses`, `colleges`) VALUES
('70', 'b.voc.(printing technology)', 'kalindi college'),
('84', 'b.voc.(software development)', 'ramanujan college'),
('88', 'b.voc.(banking operations)', 'ramanujan college'),
('79', 'b.voc.(healthcare management)', 'jesus & mary college'),
('77', 'advanced diploma(tv programme & news production)', 'maharaja agrasen college'),
('80', 'b.voc.(software development)', 'kalindi college'),
('81', 'b.voc.(retail management & it)', 'jesus & mary college');
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
