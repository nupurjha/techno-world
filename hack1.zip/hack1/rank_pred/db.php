<?php
$SETTINGS["hostname"]='localhost';
$SETTINGS["mysql_user"]='root';
$SETTINGS["mysql_pass"]='';
$SETTINGS["mysql_database"]='bvoc';


$conn = mysqli_connect($SETTINGS["hostname"], $SETTINGS["mysql_user"],$SETTINGS["mysql_pass"],$SETTINGS["mysql_database"]);
// Check connection
if (mysqli_connect_errno())
  {
  echo "Failed to connect to MySQL: " . mysqli_connect_error();
  }
?>