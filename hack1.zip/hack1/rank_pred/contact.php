<!doctype html>
<html lang="en">
<head>
	<!-- Meta, title, CSS, favicons, etc. -->
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<meta name="description" content="">
	<meta name="author" content="">
	
		<title>Contact Form With Full Validation </title>
	
	<!-- Styles -->
	<link rel='stylesheet' href='assets/css/bootstrap.min.css'>
	<link rel='stylesheet' href='assets/css/animate.min.css'>
	
	<link rel='stylesheet' href="assets/css/style.css"/>
	
	<!-- Fonts -->
	<link href='http://fonts.googleapis.com/css?family=Raleway:200,300,400,500,600,700,800' rel='stylesheet' type='text/css'>
<style>
	h1{text-align:center;
	text-shadow: 3px 3px grey;}
			
	</style>
</head>
<body>

<!-- End Hero Bg
	================================================== -->
<!-- Start Header
	================================================== -->
<center><h1>Skill Course Predictor</h1></center>

<!-- Intro
	================================================== -->
<!-- Contact
	================================================== -->
<section id="contactarea" class="parallax section" style="background-image: url(images/map.png);">
<div class="wrapsection">
	<div class="parallax-overlay" style="background-color: #1cbb9b;opacity:0.95;"></div>
	<div class="container">
		<div class="row">
			<div class="col-md-12">
				
				<form action="view.php" id="contact"  method="GET" class="text-left">
					<fieldset>
						<div class="row">
						<input type="hidden" name="new" value="1" />
							<div class="col-md-6 wow fadeIn animated animated" data-wow-delay="0.1s" data-wow-duration="2s">
								<label for="name">Marks<span class="required">*</span></label>
								<input type="text" name="marks"  size="30" value="" required/>
								<br><br><h4> Maths must be included in best four subjects to pursue courses like -:</h4>
<h6><ol>
<li> B.VOC.(WEB DESIGNING)</li>
<li>B.VOC.(PRINTING TECHNOLOGY)</li>
<li>B.VOC.(SOFTWARE DEVELOPMENT)</li>

</ol></h6>
							</div>

							<div class="col-md-6 wow fadeIn animated" data-wow-delay="0.3s" data-wow-duration="2s">
								<label for="phone">Subject</label>
								<select name="subject">
								<option value="Bachelor_of_Vocation">Bachelor of Vocation</option>
								
								
								</select>
							</div>
						</div>
						<div class="wow fadeIn animated" data-wow-delay="0.3" data-wow-duration="1.5s" >
							<center><input id="submit" type="submit" value="Send"/></center>
						</div>
					</fieldset>
				</form>
				
			</div>
		</div>
	</div>
</div>
</section>


<!-- Bootstrap core JavaScript
<!-- jQuery -->
	
<!-- Placed at the end of the document so the pages load faster -->


</body>
</html>