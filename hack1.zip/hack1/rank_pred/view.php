<html>
<head>
<style>
table {
    font-family: arial, sans-serif;
    border-collapse: collapse;
	border: 3px solid #1cbb9b;
	margin: auto;
    width: 60%;
    
	
   
}
tr{text-transform:uppercase; 
text-shadow:2px 2px grey;
}


td, th {
    border: 1px solid #1cbb9b;
    padding: 10px;
}

tr:nth-child(even) {
    background-color: #dddddd;
	
}
</style>

</head>
<body>



<table width="100%" border="1" cellspacing="0" cellpadding="500">

<tr>
    <th width="60%" style="background-color: #1cbb9b;opacity:0.95;text-align:center;"><h2><strong>COURSES</strong></h2></th>
	<th width="60%" style="background-color: #1cbb9b;opacity:0.95;text-align:center;"><h2><strong>COLLEGES</strong></h2></th>
    </tr>

<?php
require('db.php');



if(isset($_GET['new']) && $_GET['new']==1){
	
$marks = $_GET['marks'];
$subject = $_GET['subject'];


$sql = "SELECT * FROM ".$subject." WHERE percentage<= ".$marks."";
$result = $conn->query($sql);

if ($result->num_rows > 0) {
    // output data of each row
    while($row = $result->fetch_assoc()) {
		?>
		<tr>
    <td width="100" bgcolor="#CCCCCC" style="text-align:center;font-weight:bold;" ><?php echo$row['courses'];?></td>
	<td width="100" bgcolor="#CCCCCC" style="text-align:center;font-weight:bold;" ><?php echo$row['colleges'];?></td>
    </tr>

        <?php
    }
} else {
    echo "0 results";
	
	}
$conn->close();


}
else{
	header("location:form.php");
}



?>
</body>
</html>