<html>
<head>
<style>
table {
    font-family: arial, sans-serif;
    border-collapse: collapse;
	border: 3px solid red;
	margin: auto;
    width: 60%;
    
	
   
}
tr{text-transform:uppercase; 
text-shadow:5px 5px hotpink;
}


td, th {
    border: 1px solid red;
    padding: 10px;
}

tr:nth-child(even) {
    background-color: #dddddd;
	
}
</style>

</head>
<body>



<table width="100%" border="1" cellspacing="0" cellpadding="500">

<tr>
    <th width="60%" bgcolor="hotpink" style="text-align:center;"><h2><strong>COLLEGE</strong></h2></th>
    </tr>

<?php
require('db.php');



if(isset($_GET['new']) && $_GET['new']==1){
	
$marks = $_GET['marks'];
$subject = $_GET['subject'];


$sql = "SELECT * FROM ".$subject." WHERE percentage<= ".$marks."";
$result = $conn->query($sql);

if ($result->num_rows > 0) {
    // output data of each row
    while($row = $result->fetch_assoc()) {
		?>
		<tr>
    <td width="100" bgcolor="#CCCCCC" style="text-align:center;" ><?php echo$row['college'];?></td>
    </tr>

        <?php
    }
} else {
    echo "0 results";
	
	}
$conn->close();


}
else{
	header("location:form.php");
}



?>
</body>
</html>