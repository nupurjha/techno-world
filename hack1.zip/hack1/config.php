<?php
  // define('DB_SERVER', 'localhost:3306');
  // define('DB_USERNAME','');
 //  define('DB_PASSWORD','');
  // define('DB_DATABASE', 'database');
//   $db = mysqli_connect(DB_SERVER,DB_USERNAME,DB_PASSWORD,DB_DATABASE);

//mysql_connect('localhost:3306','','');
//mysql_select_db=('database');
$servername = "localhost:3306";
$username = "root";
$password = "";
$dbname="database";
// Create connection
$conn =mysqli_connect($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
} 
echo "Connected successfully";
   
//$selected = mysql_select_db('database',$conn);

  //or die("Could not select examples");
?>