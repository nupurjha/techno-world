<?php
 $full_name= $_POST["full_name"];
$from= $_POST["email"];
$subject="Received mail from '$full_name'";
$pHONE_NO= $_POST["phone_no"];
$requirements= $_POST["requirements"];
$to="contact@webworld.club";
$headers="MIME-VERSION:text/html;charset=UTF-8"."\r\n";
$headers="FROM:<$from> \r\n";
?>
<!DOCTYPE html>
<html>
<head>
<style>
header {
    padding: 3em;
    color: white;
    clear: left;
    text-align: left;
    background-image:url('grey.jpg');
}
aside{
    float: left;
    max-width: 500px;
    margin: 4;
    padding: 10em;
    background-color:#ff7043;
    text-align:centre; 
    color:white;
}
section {
    margin-left: 70px;
    border-left: 1px solid gray;
    padding: 4em;
    overflow: hidden;
    background-color:#00b3ca;
    color:white;
}
footer {
    padding:3em;
    color:white;
    text-align:right;
    background-image:url('grey.jpg');
}
input[type=text] {
    border-radius:35px;
    width: 100%;
    padding: 10px 10px;
    margin: 8px 0;
    box-sizing: border-box;
}
#content input[type=text]{
width:100%;
padding: 45px 45px;
margin: 8px 0;
box-sizing: border-box
}
input[type=submit] {
    background-color: red;
    border: none;
    color: white;
    padding: 16px 32px;
    text-decoration: none;
    margin: 4px 2px;
    cursor: pointer;
}
h2{
text-shadow:2px 2px 4px #000
}
h1{
text-shadow:1px 1px 2px white, 0 0 25px blue, 0 0 5px darkblue;
}
h4{
text-shadow:text-shadow:2px 2px 4px white 0 0 5px darkblue;
}
</style>

<header><img src="world.jpg" style="float:left;width:42px;height:42px;">
<h1><u><i>WEB WORLD</i></u></h1></header>
<aside>
<h2>WEBSITE DESIGN AND DEVELOPMENT SEVICES</h2>
  <img src="devel.jpg" alt="Avatar"  style="float:right;width:300px;height:100px;">
<ul style="list-style-type:square;"><i><h2><li>Better view across all devices.</li>
<li>Increase sales and conversion rates.</li>
<li>Improved Serach Engine Rankings.</li>
<li>Smooth User Experience</li>
<li>Future Scalability.</li>
<li>One Website All Devices- No more Separate Websites for Mobile & Desktop.</li></h2></i></ul>
</aside>
<section>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
<script>
$(document).ready(function(){
    $("input").focus(function(){
        $(this).css("background-color", "#cccccc");
    });
    $("input").blur(function(){
        $(this).css("background-color", "#ffffff");
    });
});
</script>
<form>
<b><p>FULL NAME</p>
<input type="text" name="full_name" maxlength=50">
<p>EMAIL</p>
<input type="text" name="email"maxlength=50><br>
<p>PHONE NO</p>
<input type="text" name="phone_no" ><br>
<div id="content">
<p>REQUIREMENTS</p>
<input type="text" name="requirements" maxlength=50>
</b>
</div>
<input type="submit" value="Submit" size=20>
</form>
<?php
if(isset($_POST{'submit'}))
{
if(mail($to,$subject,$phone_no,$requirements,$headers))
{
echo "thanks for mail us!we will get back asap....";
}
else
{
echo "failed to send an email";
}
}
?>
</section>
<footer><h4>Call us:9971688971<br>
Email ID:nupurjha081@gmail.com</h4></footer>
</head>
</html>